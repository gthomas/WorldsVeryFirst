"""Juris C-75T — a T-style solid body on the C-75 outline, with the C-75's bevelled edges.
Bolt-on 25.5" neck (stock T-style neck, Fender pocket), Tele bridge pickup in a vintage-style bridge plate,
neck single coil screwed to the body (no pickguard), control plate with 3-way switch, volume and tone.
Body frame as the C-75A: x+ treble, y+ toward the neck (y=0 tail), z+ up (z=0 back). Units mm.
Run: python tstyle.py  -> out_t/ (GLB, STL, DXF, report.json)"""
import json, math, os
import numpy as np
import manifold3d as m3
import build as B                       # shared CSG helpers (prism, hull, union, loft, ...)
import outline as O
import head_c75 as H

IN = 25.4
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out_t'); os.makedirs(OUT, exist_ok=True)

P = dict(
    T=44.45,                 # body thickness, 1-3/4"
    bevel_drop=11.0,         # how far each bevel falls at the outline, top and back (C-75 side elevation: ~0.45")
    scale=647.7,             # 25.5"
    comp=2.5,                # average saddle compensation
    frets=21, fret_body=16,  # body edge at the 16th fret (Tele)
    pocket_w=56.1, pocket_L=76.2, pocket_d=15.9, pocket_r=3.2,      # 2.2" heel + 0.2 mm, 3", 5/8"
    heel_t=25.4,             # neck thickness at the heel including the fingerboard
    fb_t=6.35, fb_radius=241.3, nut_w=42.0, heel_w=55.9,           # 9.5" radius, 1.65" nut
    neck_d1=21.0, neck_d12=22.5,
    action12=2.0, fret_h=1.2,
    string_spacing_bridge=54.0,  # 2-1/8"
    neck_half=35.0,          # body half-width at the neck end: pocket walls ~7 mm
    tail_half=16.0,
)

# ----------------------------------------------------------------------------- OUTLINE
O.TAIL_HALF = P['tail_half']; O.NECK_HALF = P['neck_half']
names, SHARP = O.sharp_outline()
RADII = dict(O.RADII); RADII.update(neckT=0, neckB=0)
OUTL = B.ccw(O.fillet(names, SHARP, RADII))
Y_END = SHARP[names.index('neckT')][1]
T = P['T']

# ----------------------------------------------------------------------------- BEVELS
# Inner bevel lines traced from Juris_C_75_Body_2D.pdf (body mm), as straight runs. The drawing is asymmetric
# (the bass bevel is wider through the lower bout and wraps onto the tail), and that is kept.
BASS_CHAIN = [(-55.4, 15.2), (-140.2, 137.3), (-140.9, 158.8), (-85.1, 274.2), (-84.0, 308.8), (-111.4, 387.9),
              (-82.5, 433.4), (-77.6, 433.6), (-42.0, 421.5)]
TREB_CHAIN = [(97.0, 25.9), (144.4, 119.3), (143.2, 146.2), (93.5, 256.0), (87.8, 286.5), (113.5, 359.4),
              (105.3, 367.7), (66.0, 359.0), (57.6, 358.9), (40.0, 383.0)]
# straight runs between those points (the short ones in between are the drawing's fillets): (start, end) index pairs
BASS_RUNS = [(0, 1), (2, 3), (4, 5), (5, 6), (7, 8)]
TREB_RUNS = [(0, 1), (2, 3), (4, 5), (6, 7), (8, 9)]

def _isect(p, d, q, e):
    A = np.array([d, -e]).T; t = np.linalg.solve(A, np.asarray(q) - np.asarray(p)); return np.asarray(p) + t[0] * np.asarray(d)

def bevel_lines(chain, runs):
    """merge each run's line with its neighbours: corners are where consecutive run lines meet"""
    C = np.array(chain, float)
    L = [(C[a], C[b] - C[a]) for a, b in runs]
    verts = [C[runs[0][0]]]
    for i in range(len(L) - 1):
        verts.append(_isect(L[i][0], L[i][1], L[i + 1][0], L[i + 1][1]))
    verts.append(C[runs[-1][1]])
    return np.array(verts)

BASS_V = bevel_lines(BASS_CHAIN, BASS_RUNS)
TREB_V = bevel_lines(TREB_CHAIN, TREB_RUNS)

def _outward(p, q, body_side_pt):
    d = (q - p) / np.linalg.norm(q - p); n = np.array([-d[1], d[0]])
    return n if np.dot(body_side_pt - p, n) < 0 else -n

def bevel_cutters(verts, z_top, down):
    """one plane per run: it contains the inner line at z_top and falls `bevel_drop` by the time it reaches the
    outline. Each plane only acts inside its own sector (bounded by the bisectors at its ends), so concave runs
    don't over-cut their neighbours. `down` = +1 for the top (falls toward the back), -1 for the back."""
    from shapely.geometry import Polygon, LineString
    outl = Polygon(OUTL); centre = np.array([0.0, 220.0])
    ns = [_outward(verts[i], verts[i + 1], centre) for i in range(len(verts) - 1)]
    cut = []
    for i in range(len(verts) - 1):
        p, q, n = verts[i], verts[i + 1], ns[i]
        bp = n if i == 0 else (ns[i - 1] + n) / np.linalg.norm(ns[i - 1] + n)
        bq = n if i == len(ns) - 1 else (ns[i + 1] + n) / np.linalg.norm(ns[i + 1] + n)
        # width: distance from the inner line to the outline, measured outward from the run's middle
        mid = (p + q) / 2
        ray = LineString([mid, mid + n * 200]).intersection(outl.exterior)
        pts = [ray] if ray.geom_type == 'Point' else list(getattr(ray, 'geoms', []))
        w = min(np.linalg.norm(np.array(g.coords[0]) - mid) for g in pts) if pts else 20.0
        slope = P['bevel_drop'] / w
        R = 400.0
        sector = [p, q, q + bq * R, p + bp * R]
        zs = lambda pt: z_top - down * slope * max(0.0, float(np.dot(pt - p, n)))
        top = z_top + down * 200
        pts3 = [(x, y, zs(np.array([x, y]))) for x, y in sector] + [(x, y, top) for x, y in sector]
        cut.append(B.hull(pts3))
    return B.union(cut)

def body_blank():
    return B.prism(OUTL, 0.0, T)

# ----------------------------------------------------------------------------- NECK GEOMETRY (straight, no angle)
FB_TOP_Z = T - P['pocket_d'] + P['heel_t']                 # fingerboard surface (centre) at the heel
FRET_X = lambda n: P['scale'] * (1 - 2 ** (-n / 12.0))       # distance from the nut
Y_NUT = Y_END + FRET_X(P['fret_body'])
Y_SADDLE = Y_NUT - (P['scale'] + P['comp'])
Y_HEEL = Y_END - P['pocket_L']
Y_FB_END = Y_NUT - FRET_X(P['frets']) - 6.0
Z_NUT = FB_TOP_Z + P['fret_h'] + 0.5
Z12 = FB_TOP_Z + P['fret_h'] + P['action12']
Z_SADDLE = Z_NUT + (Z12 - Z_NUT) * (Y_NUT - Y_SADDLE) / (FRET_X(12))

def string_z(y): return Z_NUT + (Z12 - Z_NUT) * (Y_NUT - y) / FRET_X(12)

# ----------------------------------------------------------------------------- ROUTES
def rrect_at(cx, cy, L, W, r, ang=0.0):
    pts = B.rrect(L, W, r, n=8)
    c, s = math.cos(math.radians(ang)), math.sin(math.radians(ang))
    return B.ccw(np.array([(cx + x * c - y * s, cy + x * s + y * c) for x, y in pts]))

def neck_pocket():
    w, L, d, r = P['pocket_w'], P['pocket_L'], P['pocket_d'], P['pocket_r']
    rect = np.array([(-w / 2, Y_HEEL), (w / 2, Y_HEEL), (w / 2, Y_END + 20), (-w / 2, Y_END + 20)])
    pk = B.prism(rect, T - d, T + 50)
    # dog-bone reliefs so a square T-style heel seats against the pocket end with a 1/4" cutter
    for sx in (-1, 1):
        pk = pk + m3.Manifold.cylinder(d + 50, r, r, 32).translate([sx * (w / 2 - r * 0.6), Y_HEEL + r * 0.6, T - d])
    return pk

NECK_SCREWS = [(sx * 19.0, Y_END - 12.7 - k * 50.8) for sx in (-1, 1) for k in (0, 1)]   # drill to your neck plate

BRIDGE = dict(W=82.5, L=92.0, back=25.0, ang=0.0)             # vintage 3-saddle plate stand-in: rear edge 25 mm behind the saddles
BRIDGE_PU = dict(cy=Y_SADDLE + 35.0, L=82.5, W=38.0, d=19.0, ang=-8.0)   # Tele bridge pickup route, slanted (treble toward the bridge)
NECK_PU = dict(cy=Y_HEEL - 22.0, L=70.0, W=31.0, d=19.0)       # Tele neck pickup, screwed to the body on springs
FERRULE_Y = Y_SADDLE - 20.0
CTRL = dict(cx=101.0, cy=176.0, L=139.7, W=31.75, cav_L=118.0, cav_W=28.0, d=36.0)     # 5-1/2 x 1-1/4" plate

def ctrl_angle():
    # parallel to the treble lower-bout bevel line
    a, b = TREB_V[1], TREB_V[2]
    return math.degrees(math.atan2(b[1] - a[1], b[0] - a[0]))

def routes():
    r = []
    r.append(neck_pocket())
    r.append(B.prism(rrect_at(0, BRIDGE_PU['cy'], BRIDGE_PU['L'], BRIDGE_PU['W'], 6.0, BRIDGE_PU['ang']), T - BRIDGE_PU['d'], T + 50))
    r.append(B.prism(rrect_at(0, NECK_PU['cy'], NECK_PU['L'], NECK_PU['W'], 12.0), T - NECK_PU['d'], T + 50))
    ang = ctrl_angle()
    r.append(B.prism(rrect_at(CTRL['cx'], CTRL['cy'], CTRL['cav_L'], CTRL['cav_W'], 6.0, ang), T - CTRL['d'], T + 50))
    # string-through: 1/8" holes and ferrule counterbores on the back
    xs = np.linspace(-P['string_spacing_bridge'] / 2, P['string_spacing_bridge'] / 2, 6)
    for x in xs:
        r.append(m3.Manifold.cylinder(T + 20, 1.6, 1.6, 16).translate([x, FERRULE_Y, -10]))
        r.append(m3.Manifold.cylinder(6.5, 4.1, 4.1, 24).translate([x, FERRULE_Y, -1]))
    # neck screws (through, 3/16" clearance) from the back
    for x, y in NECK_SCREWS:
        r.append(m3.Manifold.cylinder(T + 20, 2.4, 2.4, 20).translate([x, y, -10]))
    return B.union(r)

# ----------------------------------------------------------------------------- BODY
def build_body(bevel=True):
    body = body_blank()
    if bevel:
        for verts in (BASS_V, TREB_V):
            body = body - bevel_cutters(verts, T, +1) - bevel_cutters(verts, 0.0, -1)
    # keep the pocket walls full height: bevels stop short of the neck end (the chains end before x = +-40)
    return body - routes()

# ----------------------------------------------------------------------------- HARDWARE STAND-INS
def build_bridge():
    """vintage-style 3-saddle plate stand-in: flat plate with raised sides and back, pickup opening, 3 barrel saddles"""
    w, L = BRIDGE['W'], BRIDGE['L']; y0 = Y_SADDLE - BRIDGE['back']; t = 1.2; hw = 12.0
    rect = lambda x0, x1, ya, yb: np.array([(x0, ya), (x1, ya), (x1, yb), (x0, yb)])
    base = B.prism(rect(-w / 2, w / 2, y0, y0 + L), T, T + t)
    sides = B.prism(rect(-w / 2, -w / 2 + t, y0, y0 + 42), T, T + hw) + B.prism(rect(w / 2 - t, w / 2, y0, y0 + 42), T, T + hw)
    back = B.prism(rect(-w / 2, w / 2, y0, y0 + t), T, T + hw)
    hole = B.prism(rrect_at(0, BRIDGE_PU['cy'], BRIDGE_PU['L'] - 4, BRIDGE_PU['W'] - 4, 5.0, BRIDGE_PU['ang']), T - 1, T + 5)
    plate = (base + sides + back) - hole
    saddles = []
    sl = (w - 2 * t - 4) / 3
    for k in range(3):
        x0 = -w / 2 + t + 2 + k * sl
        saddles.append(m3.Manifold.cylinder(sl - 1.5, 3.2, 3.2, 24).rotate([0, 90, 0]).translate([x0 + 0.75, Y_SADDLE, Z_SADDLE - 3.2]))
    return plate + B.union(saddles)

def build_bridge_pickup():
    p = BRIDGE_PU
    body = B.prism(rrect_at(0, p['cy'], p['L'] - 10, p['W'] - 8, 4.0, p['ang']), T - 10, T + 8)
    poles = B.union([m3.Manifold.cylinder(1.5, 2.4, 2.4, 16).translate([x, p['cy'] + x * math.tan(math.radians(p['ang'])), T + 8])
                     for x in np.linspace(-26, 26, 6)])
    return body, poles

def build_neck_pickup():
    p = NECK_PU
    cover = B.prism(rrect_at(0, p['cy'], p['L'] - 4, p['W'] - 4, 12.0), T - 12, T + 7)
    return cover

def build_control_plate():
    ang = ctrl_angle()
    plate = B.prism(rrect_at(CTRL['cx'], CTRL['cy'], CTRL['L'], CTRL['W'], 6.0, ang), T, T + 1.6)
    c, s = math.cos(math.radians(ang)), math.sin(math.radians(ang))
    at = lambda u: (CTRL['cx'] + u * c, CTRL['cy'] + u * s)
    knobs = []
    for u, kind in ((-45.0, 'switch'), (0.0, 'vol'), (38.0, 'tone')):
        x, y = at(u)
        if kind == 'switch':
            knobs.append(m3.Manifold.cylinder(14, 1.6, 1.6, 12).translate([x, y, T + 1.6]) + m3.Manifold.cylinder(10, 5, 5, 24).translate([x, y, T + 15.6]))
        else:
            knobs.append(m3.Manifold.cylinder(17, 9.5, 9.5, 40).translate([x, y, T + 1.6]))
    return plate, B.union(knobs)

# ----------------------------------------------------------------------------- NECK (stock T-style stand-in, Juris head cut from a paddle)
def build_neck():
    """reference model of a stock 25.5" T-style neck: square heel 2.2 x 3", 9.5" board, 21 frets, flat headstock
    with the Juris outline cut from a paddle head"""
    fbt = P['fb_t']; z_fbp = FB_TOP_Z - fbt          # fingerboard gluing plane = neck wood top (flat neck)
    def width(y):
        t = (Y_NUT - y) / (Y_NUT - Y_FB_END)
        return P['nut_w'] + (P['heel_w'] - P['nut_w']) * min(1, max(0, t))
    def depth(y):
        s = Y_NUT - y; d = P['neck_d1'] + (P['neck_d12'] - P['neck_d1']) * (s - FRET_X(1)) / (FRET_X(12) - FRET_X(1))
        return d - fbt
    rings = []
    ys = np.linspace(Y_NUT - 4, Y_END + 8, 40)
    for y in ys:
        W, D = width(y) / 2, depth(y)
        loop = [(W * math.cos(a), y, z_fbp - D * math.sin(a) ** 0.85) for a in np.linspace(0, math.pi, 25)]
        loop = [(x, yy, z) for x, yy, z in loop]
        rings.append(np.array(loop))
    shaft = B.union([B.hull(list(r1) + list(r2)) for r1, r2 in zip(rings[:-1], rings[1:])])
    heel = B.prism(np.array([(-P['heel_w'] / 2, Y_HEEL), (P['heel_w'] / 2, Y_HEEL), (P['heel_w'] / 2, Y_END + 12), (-P['heel_w'] / 2, Y_END + 12)]),
                   T - P['pocket_d'], z_fbp)
    heel = heel ^ B.hull([(sx * P['heel_w'] / 2, y, z) for sx in (-1, 1) for y in (Y_HEEL, Y_END + 12) for z in (T - P['pocket_d'], z_fbp)])
    # flat headstock, face at the gluing plane, Juris outline
    HT = 14.0
    hp = np.array([(x, Y_NUT + s) for x, s in H.HEAD_OUTLINE])
    head = B.prism(B.ccw(hp), z_fbp - HT, z_fbp)
    trans = B.hull([(x * width(Y_NUT) / 2, Y_NUT - 4, z) for x in (-1, 1) for z in (z_fbp - depth(Y_NUT), z_fbp)] +
                   [(x * 26, Y_NUT + 30, z) for x in (-1, 1) for z in (z_fbp - HT, z_fbp)])
    neck = shaft + heel + head + trans
    for v, s, _ in H.TUNER_LIST:
        neck = neck - m3.Manifold.cylinder(40, 4.4, 4.4, 24).translate([v, Y_NUT + s, z_fbp - 30])
    for x, y in NECK_SCREWS:
        neck = neck - m3.Manifold.cylinder(25, 1.6, 1.6, 12).translate([x, y, T - P['pocket_d'] - 1])
    return neck

def build_fingerboard():
    fbt = P['fb_t']; R = P['fb_radius']; z0 = FB_TOP_Z - fbt
    def w(y):
        t = (Y_NUT - y) / (Y_NUT - Y_FB_END); return P['nut_w'] + (P['heel_w'] - P['nut_w']) * t
    pts = []
    for y in (Y_NUT, Y_FB_END):
        hw = w(y) / 2
        for x in np.linspace(-hw, hw, 13):
            zt = FB_TOP_Z - (R - math.sqrt(R * R - x * x))
            pts += [(x, y, z0), (x, y, zt)]
    fb = B.hull(pts)
    frets = []
    for n in range(1, P['frets'] + 1):
        y = Y_NUT - FRET_X(n); hw = w(y) / 2 - 0.5
        frets.append(B.hull([(x, y + dy, FB_TOP_Z - (R - math.sqrt(R * R - x * x)) + dz) for x in (-hw, 0, hw) for dy in (-1.2, 1.2) for dz in (-0.2, P['fret_h'] * (1 if abs(dy) < 1 else 0.4))]))
    return fb, B.union(frets)

def build_tuners():
    out = []
    z_face = FB_TOP_Z - P['fb_t']
    for v, s, sv in H.TUNER_LIST:
        y = Y_NUT + s
        out.append(m3.Manifold.cylinder(18, 3.0, 3.0, 20).translate([v, y, z_face]))
        out.append(B.hull([(v + sv * dx, y + dy, z_face - 14 - dz) for dx in (2, 26) for dy in (-7, 7) for dz in (0, 14)]))
    return B.union(out)

def build_strings():
    xs_b = np.linspace(-26.25, 26.25, 6); xs_n = np.linspace(-17.5, 17.5, 6)
    out = []; lines = []
    for i in range(6):
        a = np.array([xs_b[i], FERRULE_Y, T + 1.5]); s = np.array([xs_b[i], Y_SADDLE, Z_SADDLE]); nut = np.array([xs_n[i], Y_NUT, Z_NUT])
        side = -1 if i < 3 else 1; k = i if i < 3 else 5 - i
        post = np.array([side * H.TUNER_POS[k][0], Y_NUT + H.TUNER_POS[k][1], FB_TOP_Z - P['fb_t'] + 8])
        pts = [a, s, nut, post]; lines.append([p.tolist() for p in pts])
        for p, q in zip(pts[:-1], pts[1:]):
            out.append(B.hull([p + d for d in B.sphere_pts(0.3)] + [q + d for d in B.sphere_pts(0.3)]))
    return B.union(out), lines

def build_jack():
    """Tele cup jack on the treble tail edge (drilled by hand, 7/8")"""
    a, b = SHARP[names.index('tailR')], SHARP[names.index('tTail')]
    m = a + (b - a) * 0.55; d = (b - a) / np.linalg.norm(b - a); n = np.array([d[1], -d[0]])
    ang = math.degrees(math.atan2(n[1], n[0]))
    cup = m3.Manifold.cylinder(3, 11.1, 11.1, 32).rotate([0, 90, 0]).rotate([0, 0, ang]).translate([m[0], m[1], T / 2])
    bore = m3.Manifold.cylinder(30, 11.1, 11.1, 32).rotate([0, 90, 0]).rotate([0, 0, ang]).translate([*(m - n * 27), T / 2])
    return cup, bore, m, n

# ----------------------------------------------------------------------------- MAIN
def main():
    import trimesh
    parts = {}
    body = build_body()
    cup, bore, jm, jn = build_jack()
    parts['body'] = body - bore
    parts['bridge'] = build_bridge()
    bpu, poles = build_bridge_pickup(); parts['bridge_pickup'] = bpu; parts['pickup_poles'] = poles
    parts['neck_pickup'] = build_neck_pickup()
    plate, knobs = build_control_plate(); parts['control_plate'] = plate; parts['knobs'] = knobs
    parts['jack'] = cup
    parts['neck'] = build_neck()
    fb, frets = build_fingerboard(); parts['fingerboard'] = fb; parts['frets'] = frets
    parts['tuners'] = build_tuners()
    st, lines = build_strings(); parts['strings'] = st
    MAT = dict(body='ash', bridge='nickel', bridge_pickup='black', pickup_poles='nickel', neck_pickup='nickel', control_plate='nickel',
               knobs='nickel', jack='nickel', neck='maple', fingerboard='maple_fb', frets='nickel', tuners='nickel', strings='steel')
    GROUP = dict(body='Body', bridge='Hardware', bridge_pickup='Pickups', pickup_poles='Pickups', neck_pickup='Pickups', control_plate='Hardware',
                 knobs='Hardware', jack='Hardware', neck='Neck', fingerboard='Neck', frets='Neck', tuners='Hardware', strings='Strings')
    EXPLODE = dict(Body=(0, 0, 0), Neck=(0, 60, 40), Pickups=(0, 0, 50), Hardware=(0, 0, 80), Strings=(0, 0, 110))
    scene = trimesh.Scene(); man_ok = {}; vols = {}
    for k, m in parts.items():
        tm = B.to_trimesh(m); man_ok[k] = bool(tm.is_watertight); vols[k] = m.volume()
        scene.add_geometry(tm, node_name=k, geom_name=k, metadata=dict(material=MAT[k], group=GROUP[k], explode=EXPLODE[GROUP[k]]))
        if k in ('body', 'neck'): tm.export(os.path.join(OUT, f'{k}.stl'))
    scene.export(os.path.join(OUT, 'juris_c75t.glb'))
    DENS = dict(ash=480, maple=700)
    mass = dict(body=vols['body'] * 480e-6, neck=(vols['neck'] + vols['fingerboard']) * 700e-6)
    hw = dict(bridge=130, pickups=150, control=110, tuners=198, strings=10, frets=20, jack=10, neckplate=40)
    total = sum(mass.values()) + sum(hw.values())
    report = dict(units='mm', params=P, body_length=float(SHARP[:, 1].max()), lower_bout=float(OUTL[:, 0].max() - OUTL[:, 0].min()),
                  y_end=float(Y_END), y_nut=float(Y_NUT), y_saddle=float(Y_SADDLE), fb_top_above_body=float(FB_TOP_Z - T),
                  string_above_body_at_saddle=float(Z_SADDLE - T), saddle_z=float(Z_SADDLE),
                  masses_g={k: round(v, 1) for k, v in mass.items()}, hardware_g=hw, total_mass_g=round(total), total_mass_lb=round(total / 453.6, 2),
                  manifold=man_ok, bevel=dict(bass=BASS_V.round(1).tolist(), treble=TREB_V.round(1).tolist()),
                  ctrl_angle_deg=ctrl_angle(), jack=dict(at=jm.tolist(), normal=jn.tolist()))
    json.dump(report, open(os.path.join(OUT, 'report.json'), 'w'), indent=1)
    meta = {k: dict(material=MAT[k], group=GROUP[k], explode=list(EXPLODE[GROUP[k]])) for k in parts}
    json.dump(dict(meta=meta, strings=lines), open(os.path.join(OUT, 'meta.json'), 'w'))
    print(json.dumps({k: report[k] for k in ('body_length', 'lower_bout', 'y_saddle', 'fb_top_above_body', 'string_above_body_at_saddle', 'total_mass_lb')}))
    print('manifold', man_ok)
    return parts

if __name__ == '__main__':
    main()
