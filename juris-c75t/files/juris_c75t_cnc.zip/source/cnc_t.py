"""CNC package for the Juris C-75T body: STL + STEP in machining orientation, setup DXF, routing template,
and a headstock template for cutting the Juris outline from a paddle-head T-style neck.
Run: python cnc_t.py  -> cnc_t/"""
import json, math, os
import numpy as np, trimesh, ezdxf
import cnc as C
import tstyle as TS
import build as B
import head_c75 as H

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'cnc_t'); os.makedirs(OUT, exist_ok=True)

def main():
    body = TS.build_body()
    d = os.path.join(OUT, 'body'); os.makedirs(d, exist_ok=True)
    tm = C.tm_of(body)
    tm, off = C.place(tm, None, 'top')
    tm.export(os.path.join(d, 'body.stl'))
    C.write_step(trimesh.load(os.path.join(d, 'body.stl')), os.path.join(d, 'body.step'))
    chk = C.check_step(os.path.join(d, 'body.step'))
    if not (chk['valid'] and chk['solids'] == 1):
        C.write_step(trimesh.load(os.path.join(d, 'body.stl')), os.path.join(d, 'body.step'), unify=False)
        chk = C.check_step(os.path.join(d, 'body.step'))
    area, bad, _ = C.reach_check(tm, 0.5)
    tr = lambda pts: [(float(x) + off[0], float(y) + off[1]) for x, y in pts]
    ang = TS.ctrl_angle()
    extra = {'OUTER_PROFILE': [tr(TS.OUTL)],
             'BEVEL_LINES_top_and_back': [tr(TS.BASS_V), tr(TS.TREB_V)],
             f'NECK_POCKET_{TS.P["pocket_d"]}mm': [tr(np.array([(-TS.P['pocket_w'] / 2, TS.Y_HEEL), (TS.P['pocket_w'] / 2, TS.Y_HEEL),
                                                                (TS.P['pocket_w'] / 2, TS.Y_END), (-TS.P['pocket_w'] / 2, TS.Y_END)]))],
             f'BRIDGE_PICKUP_{TS.BRIDGE_PU["d"]}mm': [tr(TS.rrect_at(0, TS.BRIDGE_PU['cy'], TS.BRIDGE_PU['L'], TS.BRIDGE_PU['W'], 6.0, TS.BRIDGE_PU['ang']))],
             f'NECK_PICKUP_{TS.NECK_PU["d"]}mm': [tr(TS.rrect_at(0, TS.NECK_PU['cy'], TS.NECK_PU['L'], TS.NECK_PU['W'], 12.0))],
             f'CONTROL_CAVITY_{TS.CTRL["d"]}mm': [tr(TS.rrect_at(TS.CTRL['cx'], TS.CTRL['cy'], TS.CTRL['cav_L'], TS.CTRL['cav_W'], 6.0, ang))],
             'BRIDGE_PLATE_outline': [tr(np.array([(-TS.BRIDGE['W'] / 2, TS.Y_SADDLE - TS.BRIDGE['back']), (TS.BRIDGE['W'] / 2, TS.Y_SADDLE - TS.BRIDGE['back']),
                                                   (TS.BRIDGE['W'] / 2, TS.Y_SADDLE - TS.BRIDGE['back'] + TS.BRIDGE['L']), (-TS.BRIDGE['W'] / 2, TS.Y_SADDLE - TS.BRIDGE['back'] + TS.BRIDGE['L'])]))],
             'CONTROL_PLATE_outline': [tr(TS.rrect_at(TS.CTRL['cx'], TS.CTRL['cy'], TS.CTRL['L'], TS.CTRL['W'], 6.0, ang))]}
    circ = lambda c, r: [(c[0] + r * math.cos(t), c[1] + r * math.sin(t)) for t in np.linspace(0, 2 * math.pi, 48)[:-1]]
    xs = np.linspace(-TS.P['string_spacing_bridge'] / 2, TS.P['string_spacing_bridge'] / 2, 6)
    extra['STRING_THROUGH_3.2mm_ferrules_8.2mm_x6deep_from_back'] = [tr(circ((x, TS.FERRULE_Y), 1.6)) for x in xs]
    extra['NECK_SCREWS_4.8mm_through_check_against_neck_plate'] = [tr(circ(p, 2.4)) for p in TS.NECK_SCREWS]
    C.setup_dxf(os.path.join(d, 'body_setup.dxf'), tm, 'JURIS C-75T  BODY  origin: XY centre, Z0 = top of body', extra)
    lo, hi = tm.bounds; size = hi - lo
    rep = dict(body=dict(part_size_mm=[round(float(x), 1) for x in size], stock_in=[round(float(size[0]) / 25.4 + 1, 2), round(float(size[1]) / 25.4 + 1, 2), round(float(size[2]) / 25.4 + 0.08, 2)],
                         watertight=bool(tm.is_watertight), undercut_area_mm2=round(area, 1), step=chk, origin_offset=off.round(3).tolist(),
                         notes='Setup A from the top: bevels (1/4" ball-nose), neck pocket, pickup routes, control cavity, profile. Setup B: flip about X: back bevels, ferrule counterbores; string and neck-screw holes drilled through.'))
    print('body', json.dumps({k: rep['body'][k] for k in ('part_size_mm', 'stock_in', 'watertight', 'undercut_area_mm2')}), chk)

    # custom neck (tilt-back head) and fingerboard: X along the neck, Z0 at the gluing plane (neck) / board bottom
    Tm = np.array([[0, 1, 0, 0], [-1, 0, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1.0]])
    TS.build_neck.holes = False                     # tuner holes are drilled square to the angled face as a separate op
    neck = TS.build_neck(); TS.build_neck.holes = True
    fb, _ = TS.build_fingerboard()
    for name, man, z0, note in (('neck', neck, 'top', 'Setup A: gluing plane, truss rod channel (1/4 x 3/8 in), angled headstock face, access slot. Setup B: flip about X: back carve, volute, heel, headstock back. Tuner holes 11/32 in square to the face, separate op.'),
                                ('fingerboard', fb, 'bottom', 'Flat side down: 9.5 in radius top, 21 fret slots (0.6 mm), taper profile.')):
        dd = os.path.join(OUT, name); os.makedirs(dd, exist_ok=True)
        t2 = C.tm_of(man); t2, off2 = C.place(t2, Tm, z0)
        t2.export(os.path.join(dd, f'{name}.stl'))
        C.write_step(trimesh.load(os.path.join(dd, f'{name}.stl')), os.path.join(dd, f'{name}.step'))
        ck = C.check_step(os.path.join(dd, f'{name}.step'))
        if not (ck['valid'] and ck['solids'] == 1):
            C.write_step(trimesh.load(os.path.join(dd, f'{name}.stl')), os.path.join(dd, f'{name}.step'), unify=False); ck = C.check_step(os.path.join(dd, f'{name}.step'))
        ar, _, _ = C.reach_check(t2, 0.5)
        C.setup_dxf(os.path.join(dd, f'{name}_setup.dxf'), t2, f'JURIS C-75T  {name.upper()}  origin: XY centre, Z0 = part {z0}')
        lo2, hi2 = t2.bounds; sz = hi2 - lo2
        rep[name] = dict(part_size_mm=[round(float(x), 1) for x in sz], watertight=bool(t2.is_watertight), undercut_area_mm2=round(ar, 1), step=ck, notes=note)
        print(name, json.dumps({k: rep[name][k] for k in ('part_size_mm', 'watertight', 'undercut_area_mm2')}), ck)

    # headstock template for a paddle-head T-style neck: Juris outline and tuner holes, nut line at y = 0
    doc = ezdxf.new('R2010'); doc.units = ezdxf.units.MM; ms = doc.modelspace()
    for n, c in [('OUTLINE', 7), ('TUNER_HOLES_8.73mm', 1), ('NUT_LINE', 3), ('CENTRELINE', 8), ('NOTES', 2)]: doc.layers.add(n, color=c)
    hp = [(float(x), float(s)) for x, s in H.HEAD_OUTLINE]
    ms.add_lwpolyline(hp, close=True, dxfattribs={'layer': 'OUTLINE'})
    for v, s, _ in H.TUNER_LIST: ms.add_circle((v, s), H.TUNER_HOLE / 2, dxfattribs={'layer': 'TUNER_HOLES_8.73mm'})
    ms.add_line((-30, 0), (30, 0), dxfattribs={'layer': 'NUT_LINE'}); ms.add_line((0, -10), (0, 215), dxfattribs={'layer': 'CENTRELINE'})
    ms.add_text('Juris headstock face (tilt-back, 13 deg): outline, 11/32" tuner holes for Grover 133N, measured along the face from the nut line.',
                dxfattribs={'layer': 'NOTES', 'height': 3}).set_placement((-60, -12))
    doc.saveas(os.path.join(OUT, 'headstock_face_template.dxf'))
    json.dump(rep, open(os.path.join(OUT, 'cnc_report.json'), 'w'), indent=1)

if __name__ == '__main__':
    main()
