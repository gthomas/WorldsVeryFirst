"""Lighter-top study: build each variant's top, then run the static + modal check on it."""
import json, os, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
V = {
    'v0': dict(top_plateau_t=6.0, top_fall_t_at_plateau=3.8, beam_h=8.0, bar_h=9.0, xbar_h=7.0),
    'v1': dict(top_plateau_t=5.0, top_fall_t_at_plateau=3.4, beam_h=8.0, bar_h=8.0, xbar_h=7.0),
    'v2': dict(top_plateau_t=4.5, top_fall_t_at_plateau=3.2, beam_h=7.0, bar_h=7.0, xbar_h=6.0),
    'v3': dict(top_plateau_t=4.0, top_fall_t_at_plateau=3.0, beam_h=7.0, bar_h=6.0, xbar_h=6.0),
    'v4': dict(top_plateau_t=3.5, top_fall_t_at_plateau=2.8, beam_h=6.0, bar_h=5.0, xbar_h=5.0),
    'v5': dict(top_plateau_t=3.2, top_fall_t_at_plateau=2.6, beam_h=5.0, bar_h=4.5, xbar_h=4.5),
}
tags = sys.argv[1:] or list(V)
MK = r'''
import build as B, json, sys
tag = sys.argv[1]
full = B.to_trimesh(B.build_top()); bind = B.to_trimesh(B.top_binding()) if hasattr(B, 'top_binding') else None
B.build_collars = lambda bi: B.m3.Manifold()
B.to_trimesh(B.build_top()).export(f'out/study_top_{tag}.stl')
print(json.dumps(dict(top_g=full.volume * 430e-6)))
'''
for t in tags:
    env = dict(os.environ, JURIS_P=json.dumps(V[t]))
    r = subprocess.run([sys.executable, '-c', MK, t], cwd=ROOT, env=env, capture_output=True, text=True)
    mass = json.loads(r.stdout.strip().splitlines()[-1])
    env.update(FEA_MESH=f'out/study_top_{t}.stl', FEA_TAG=f'study_{t}', FEA_MODES='4')
    env['FEA_MODES'] = '0'
    subprocess.run([sys.executable, 'fea.py', '850', '40'], cwd=ROOT, env=env, capture_output=True, text=True)
    env.update(FEA_MODES='4', FEA_ONLY_MODES='1')
    r2 = subprocess.run([sys.executable, 'fea.py', '850', '40'], cwd=ROOT, env=env, capture_output=True, text=True)
    if r2.returncode: print(t, 'modes failed', r2.returncode, r2.stderr[-300:], flush=True)
    env.pop('FEA_ONLY_MODES')
    fp = os.path.join(ROOT, f'out/fea_study_{t}.json')
    if not os.path.exists(fp): print(t, 'static failed', flush=True); continue
    f = json.load(open(fp))
    row = dict(tag=t, minratio=os.environ.get('FEA_MINRATIO', '1.6'), **V[t], **mass, sink=f['bridge_down_mm'], max=f['max_down_mm'],
               sf=min(f['safety_factor_p99'].values()), modes=f.get('modes'))
    print(json.dumps(row), flush=True)
    open(os.path.join(ROOT, 'out/study.jsonl'), 'a').write(json.dumps(row) + '\n')
