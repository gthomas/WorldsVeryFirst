Juris A-6 boards, Rev D, 2026-11-24
Main board JPI-A6-M: 100 x 64 mm, 4-layer (both boards now inside the 100 x 100 mm price tier). Mounting holes on an 88 x 52 mm rectangle.
Control board JPI-A6-C: 80 x 74 mm, 4-layer, signal-order placement; reverb return reaches VR4.
R17 = 18k (was 10k): sized so the amp averages <= ~120 W with every knob maxed, for the 160 W GST160A48-R7B brick.
Both: DRC clean (lib_footprint_issues are local library-path notices only).
