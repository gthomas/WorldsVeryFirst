Juris A-6 boards, 2026-11-24
Main board JPI-A6-M: Rev C (4-layer).
Control board JPI-A6-C: Rev D (4-layer): signal-order placement; reverb return now reaches VR4 (Rev B/C had it on a separate net).
Both: DRC clean (no unconnected items, clearance or silk errors; lib_footprint_issues are local library-path notices only).
