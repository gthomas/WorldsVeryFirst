Juris A-6 boards, Rev D, 2026-11-24
Main board JPI-A6-M: 100 x 64 mm, 4-layer. U4 = RECOM R-78HB12-0.5 (SIP-3: 1 +Vin, 2 GND, 3 +12 V), C21 = 3.3 uF 100 V X7R 1210 at its input. Mounting holes on an 88 x 52 mm rectangle.
Control board JPI-A6-C: 80 x 74 mm, 4-layer, signal-order placement; reverb return reaches VR4.
R17 = 18k: amp averages <= ~120 W with every knob maxed, for the 160 W GST160A48-R7B brick.
Both: DRC clean (lib_footprint_issues are local library-path notices only).
