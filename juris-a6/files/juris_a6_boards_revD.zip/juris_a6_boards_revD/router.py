"""Small 2-layer grid router for the Brief boards (no external autorouter).

Grid A* (8-way moves, vias as layer changes), one net at a time, power nets first. Clearance is
checked with a distance transform of other nets' copper, so each net gets its own track width.
Multi-pin nets grow a tree: each further pad is routed to the nearest point of the tree so far.
GND is routed last as ordinary tracks and both copper layers are also poured with GND.
"""
import os, sys, math, heapq, re, collections
import numpy as np
from scipy import ndimage
import pcbnew
from pcbnew import VECTOR2I, FromMM, ToMM

RES = 0.2           # mm per grid cell
CLR = 0.2          # mm copper clearance (design rule)
MARGIN = 0.1       # extra routing margin for grid quantisation
VIA_D, VIA_DRILL = 0.8, 0.4
VIA_COST = 14.0
WIDTH = {"+48": 1.2, "+48_IN": 1.2, "GND": 0.5, "+12V": 0.6, "+30V": 0.5, "+9V": 0.6, "VG": 0.4}
DEFAULT_W = 0.25
ORDER_FIRST = ["+48_IN", "+48", "+12V", "+30V", "+9V", "VG"]

class Grid:
    def __init__(self, board):
        self.b = board
        bb = board.GetBoardEdgesBoundingBox()
        self.x0, self.y0 = ToMM(bb.GetLeft()), ToMM(bb.GetTop())
        self.nx = int(math.ceil(ToMM(bb.GetWidth()) / RES)) + 1
        self.ny = int(math.ceil(ToMM(bb.GetHeight()) / RES)) + 1
        self.copper = [np.zeros((self.ny, self.nx), np.int32) for _ in range(2)]   # net code of copper, 0 = empty
        self.edge = np.ones((self.ny, self.nx), bool)
        m = int(math.ceil(0.6 / RES))
        self.edge[m:-m, m:-m] = False
        for d in board.GetDrawings():                       # internal cutouts (rectangles on Edge.Cuts)
            if d.GetLayer() == pcbnew.Edge_Cuts and d.GetShape() == pcbnew.SHAPE_T_RECT:
                bb = d.GetBoundingBox()
                i0, j0 = self.ij(ToMM(bb.GetLeft()) - 1.0, ToMM(bb.GetTop()) - 1.0)
                i1, j1 = self.ij(ToMM(bb.GetRight()) + 1.0, ToMM(bb.GetBottom()) + 1.0)
                self.edge[max(i0, 0):i1 + 1, max(j0, 0):j1 + 1] = True
        self.netpads = collections.defaultdict(list)                                  # net -> [(cells per layer)]
        for fp in board.GetFootprints():
            for p in fp.Pads():
                self.add_pad(p)

    def ij(self, x, y):
        return int(round((y - self.y0) / RES)), int(round((x - self.x0) / RES))

    def xy(self, i, j):
        return self.x0 + j * RES, self.y0 + i * RES

    def pad_layers(self, p):
        if p.GetAttribute() in (pcbnew.PAD_ATTRIB_PTH,): return [0, 1]
        if p.GetAttribute() == pcbnew.PAD_ATTRIB_NPTH: return [0, 1]
        return [0] if p.IsOnLayer(pcbnew.F_Cu) else [1]

    def add_pad(self, p):
        bb = p.GetBoundingBox()
        x0, y0, x1, y1 = ToMM(bb.GetLeft()), ToMM(bb.GetTop()), ToMM(bb.GetRight()), ToMM(bb.GetBottom())
        i0, j0 = self.ij(x0, y0); i1, j1 = self.ij(x1, y1)
        i0, j0 = max(i0, 0), max(j0, 0); i1, j1 = min(i1, self.ny - 1), min(j1, self.nx - 1)
        code = p.GetNetCode() if p.GetNetCode() > 0 else -1      # unconnected pads / NPTH = obstacle
        cells = []
        for L in self.pad_layers(p):
            self.copper[L][i0:i1 + 1, j0:j1 + 1] = code
            cells.append((L, i0, j0, i1, j1))
        if code > 0:
            c = p.GetPosition(); ci, cj = self.ij(ToMM(c.x), ToMM(c.y))
            self.netpads[code].append(dict(layers=self.pad_layers(p), center=(ci, cj), rect=cells, pad=p))

    def free_mask(self, code, half_w):
        """Cells where a track centre of this net (half width half_w) keeps clearance to other copper."""
        masks = []
        for L in range(2):
            other = (self.copper[L] != 0) & (self.copper[L] != code)
            dist = ndimage.distance_transform_edt(~other) * RES
            ok = (dist > half_w + CLR + MARGIN) & ~self.edge
            ok |= (self.copper[L] == code)
            masks.append(ok)
        vr = VIA_D / 2
        via_ok = np.ones_like(masks[0])
        for L in range(2):
            other = (self.copper[L] != 0) & (self.copper[L] != code)
            dist = ndimage.distance_transform_edt(~other) * RES
            via_ok &= (dist > vr + CLR + MARGIN + 0.1)
        via_ok &= ~self.edge
        return masks, via_ok

    def paint(self, code, cells, half_w):
        """Mark copper for a routed path (list of (L,i,j)), dilated by its half width."""
        r = max(1, int(math.ceil(half_w / RES)))
        yy, xx = np.mgrid[-r:r + 1, -r:r + 1]; disk = (xx ** 2 + yy ** 2) <= (half_w / RES + 0.5) ** 2
        for L in range(2):
            m = np.zeros((self.ny, self.nx), bool)
            for (l, i, j) in cells:
                if l == L: m[i, j] = True
            if m.any():
                m = ndimage.binary_dilation(m, structure=disk)
                self.copper[L][m & (self.copper[L] == 0)] = code

    def paint_via(self, code, i, j):
        r = int(math.ceil(VIA_D / 2 / RES))
        for L in range(2):
            sl = self.copper[L][max(0, i - r):i + r + 1, max(0, j - r):j + r + 1]
            sl[sl == 0] = code

MOVES = [(0, 1, 1.0), (1, 0, 1.0), (0, -1, 1.0), (-1, 0, 1.0), (1, 1, 1.414), (1, -1, 1.414), (-1, 1, 1.414), (-1, -1, 1.414)]

def astar(g, masks, via_ok, starts, targets):
    """starts: set of (L,i,j); targets: set of (L,i,j). Returns path list or None."""
    tlist = list(targets)
    tarr = np.array([(i, j) for _, i, j in tlist])
    def h(i, j):
        d = np.abs(tarr - (i, j)); dx, dy = d[:, 1], d[:, 0]
        return float(np.min(np.maximum(dx, dy) + 0.414 * np.minimum(dx, dy)))
    openq = []; came = {}; gs = {}
    for s in starts:
        gs[s] = 0.0; heapq.heappush(openq, (h(s[1], s[2]), 0.0, s))
    tset = set(targets); n = 0
    while openq:
        f, gc, cur = heapq.heappop(openq)
        if gc > gs.get(cur, 1e18): continue
        if cur in tset:
            path = [cur]
            while path[-1] in came: path.append(came[path[-1]])
            return path[::-1]
        n += 1
        if n > 600000: return None
        L, i, j = cur
        nbrs = []
        for di, dj, c in MOVES:
            ni, nj = i + di, j + dj
            if 0 <= ni < g.ny and 0 <= nj < g.nx and masks[L][ni, nj]:
                if di and dj and not (masks[L][i, nj] and masks[L][ni, j]): continue
                nbrs.append(((L, ni, nj), c))
        if via_ok[i, j] and masks[1 - L][i, j]:
            nbrs.append(((1 - L, i, j), VIA_COST))
        for nb, c in nbrs:
            ng = gc + c
            if ng < gs.get(nb, 1e18):
                gs[nb] = ng; came[nb] = cur
                heapq.heappush(openq, (ng + h(nb[1], nb[2]), ng, nb))
    return None

def pad_cells(g, pad, masks):
    out = set()
    p = pad["pad"]
    for (L, i0, j0, i1, j1) in pad["rect"]:
        for i in range(i0, i1 + 1):
            for j in range(j0, j1 + 1):
                x, y = g.xy(i, j)
                if masks[L][i, j] and p.HitTest(VECTOR2I(FromMM(x), FromMM(y)), -FromMM(0.05)):
                    out.add((L, i, j))
    ci, cj = pad["center"]
    for L in pad["layers"]:
        out.add((L, ci, cj))
    return out

def to_segments(path):
    """Collapse a cell path into straight runs per layer; return segments and via points."""
    segs, vias = [], []
    run = [path[0]]
    for a, b in zip(path, path[1:]):
        if a[0] != b[0]:
            if len(run) > 1: segs.append(run)
            vias.append((a[1], a[2])); run = [b]; continue
        if len(run) >= 2:
            d0 = (run[-1][1] - run[-2][1], run[-1][2] - run[-2][2]); d1 = (b[1] - a[1], b[2] - a[2])
            if d0 != d1:
                segs.append(run); run = [run[-1]]
        run.append(b)
    if len(run) > 1: segs.append(run)
    return [(r[0][0], r[0][1], r[0][2], r[-1][1], r[-1][2]) for r in segs], vias

def route_board(board, priority=(), seed=None):
    g = Grid(board)
    codes = {board.GetNetInfo().GetNetItem(i).GetNetname(): board.GetNetInfo().GetNetItem(i).GetNetCode() for i in range(1, board.GetNetCount())}
    names = {v: k for k, v in codes.items()}
    # order: power rails first, then signal nets by pad spread (short first), GND last
    def spread(code):
        c = np.array([p["center"] for p in g.netpads[code]]); return float(np.ptp(c[:, 0]) + np.ptp(c[:, 1])) if len(c) > 1 else 0
    order = [codes[n] for n in priority if n in codes]
    order += [codes[n] for n in ORDER_FIRST if n in codes and codes[n] not in order]
    rest = [c for n, c in codes.items() if n not in ORDER_FIRST and n != "GND" and len(g.netpads[c]) > 1 and c not in order]
    rest = sorted(rest, key=spread)
    if seed is not None:
        import random; rnd = random.Random(seed)
        rest = sorted(rest, key=lambda c: spread(c) * rnd.uniform(0.5, 1.5))
    order += rest
    four = board.GetCopperLayerCount() >= 4
    if "GND" in codes and codes["GND"] not in order and not four: order.append(codes["GND"])
    lay = {0: pcbnew.F_Cu, 1: pcbnew.B_Cu}
    failed = []; nseg = nvia = 0
    for code in order:
        name = names[code]; pads = g.netpads[code]
        if len(pads) < 2: continue
        w = WIDTH.get(name, DEFAULT_W); hw = w / 2
        ni = board.FindNet(name)
        masks, via_ok = g.free_mask(code, hw)
        # start from the pad nearest the centroid
        cen = np.mean([p["center"] for p in pads], axis=0)
        pads = sorted(pads, key=lambda p: (p["center"][0] - cen[0]) ** 2 + (p["center"][1] - cen[1]) ** 2)
        tree = pad_cells(g, pads[0], masks)
        todo = pads[1:]
        while todo:
            # connect the pad closest to the tree next
            tarr = np.array([(i, j) for _, i, j in tree])
            todo.sort(key=lambda p: float(np.min(np.abs(tarr - p["center"]).sum(axis=1))))
            p = todo.pop(0)
            src = pad_cells(g, p, masks)
            if src & tree: tree |= src; continue
            path = astar(g, masks, via_ok, src, tree)
            if path is None:
                failed.append(name); continue
            segs, vias = to_segments(path)
            for L, i0, j0, i1, j1 in segs:
                x0, y0 = g.xy(i0, j0); x1, y1 = g.xy(i1, j1)
                t = pcbnew.PCB_TRACK(board); t.SetStart(VECTOR2I(FromMM(x0), FromMM(y0))); t.SetEnd(VECTOR2I(FromMM(x1), FromMM(y1)))
                t.SetWidth(FromMM(w)); t.SetLayer(lay[L]); t.SetNet(ni); board.Add(t); nseg += 1
            for i, j in vias:
                x, y = g.xy(i, j)
                v = pcbnew.PCB_VIA(board); v.SetPosition(VECTOR2I(FromMM(x), FromMM(y)))
                v.SetWidth(FromMM(VIA_D)); v.SetDrill(FromMM(VIA_DRILL)); v.SetNet(ni); v.SetViaType(pcbnew.VIATYPE_THROUGH); board.Add(v); nvia += 1
                g.paint_via(code, i, j)
            g.paint(code, path, hw)
            tree |= set(path) | src
            masks, via_ok = g.free_mask(code, hw)
    # 4 layers: GND is the inner planes. Through-hole GND pads reach them directly; each surface-mount
    # GND pad gets a short stub to its own via (nearest free spot within 2.5 mm).
    if four and "GND" in codes:
        code = codes["GND"]; ni = board.FindNet("GND"); w = WIDTH["GND"]; hw = w / 2; nfan = 0
        for pd in g.netpads[code]:
            if len(pd["layers"]) > 1: continue
            masks, via_ok = g.free_mask(code, hw)
            L = pd["layers"][0]; ci, cj = pd["center"]; r = int(2.5 / RES)
            i0, i1, j0, j1 = max(ci - r, 0), min(ci + r, g.ny - 1), max(cj - r, 0), min(cj + r, g.nx - 1)
            src = pad_cells(g, pd, masks)
            near = np.zeros_like(via_ok)                       # no via in or touching the pad itself
            for _, a_, b_ in src: near[a_, b_] = True
            near = ndimage.binary_dilation(near, iterations=int((VIA_D / 2 + 0.2) / RES) + 1)
            cand = [(L, i, j) for i in range(i0, i1 + 1) for j in range(j0, j1 + 1) if via_ok[i, j] and not near[i, j]]
            if not cand: failed.append("GND"); continue
            noz = np.zeros_like(via_ok)
            path = astar(g, masks, noz, src, set(cand))
            if path is None: failed.append("GND"); continue
            segs, _ = to_segments(path)
            for Ls, a0, b0, a1, b1 in segs:
                x0, y0 = g.xy(a0, b0); x1, y1 = g.xy(a1, b1)
                if (a0, b0) == (a1, b1): continue
                t = pcbnew.PCB_TRACK(board); t.SetStart(VECTOR2I(FromMM(x0), FromMM(y0))); t.SetEnd(VECTOR2I(FromMM(x1), FromMM(y1)))
                t.SetWidth(FromMM(w)); t.SetLayer(lay[Ls]); t.SetNet(ni); board.Add(t); nseg += 1
            _, vi, vj = path[-1]; x, y = g.xy(vi, vj)
            v = pcbnew.PCB_VIA(board); v.SetPosition(VECTOR2I(FromMM(x), FromMM(y)))
            v.SetWidth(FromMM(VIA_D)); v.SetDrill(FromMM(VIA_DRILL)); v.SetNet(ni); v.SetViaType(pcbnew.VIATYPE_THROUGH); board.Add(v); nvia += 1
            g.paint_via(code, vi, vj); g.paint(code, path, hw); nfan += 1
        print(f"  {nfan} GND fan-out vias")
    # GND stitching vias wherever both layers are clear, every ~4 mm, to tie the two pours together
    if "GND" in codes:
        code = codes["GND"]; masks, via_ok = g.free_mask(code, 0.0)
        far = np.ones_like(via_ok)
        for L in range(2):
            other = (g.copper[L] != 0)
            far &= ndimage.distance_transform_edt(~other) * RES > VIA_D / 2 + 0.6
        step = int((8.0 if four else 4.0) / RES); ni = board.FindNet("GND"); nst = 0
        for i in range(step // 2, g.ny, step):
            for j in range(step // 2, g.nx, step):
                if via_ok[i, j] and far[i, j]:
                    x, y = g.xy(i, j)
                    v = pcbnew.PCB_VIA(board); v.SetPosition(VECTOR2I(FromMM(x), FromMM(y)))
                    v.SetWidth(FromMM(VIA_D)); v.SetDrill(FromMM(VIA_DRILL)); v.SetNet(ni); v.SetViaType(pcbnew.VIATYPE_THROUGH); board.Add(v); nst += 1
                    g.paint_via(code, i, j)
        print(f"  {nst} GND stitching vias")
    return nseg, nvia, failed

if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__))
    for name in (sys.argv[1:] or ["main", "control"]):
        priority = []
        for attempt in range(int(os.environ.get('ATTEMPTS', 6))):
            b = pcbnew.LoadBoard(os.path.join(here, f"{name}.kicad_pcb"))
            ds = b.GetDesignSettings(); ds.m_MinClearance = FromMM(0.2); ds.m_TrackMinWidth = FromMM(0.25)
            seed = attempt if attempt >= 3 else None
            if attempt >= 3: priority = priority[-6:]
            nseg, nvia, failed = route_board(b, priority, seed)
            # drop same-net vias that landed on top of one another (fan-out next to a stitching via)
            vs = [t for t in b.GetTracks() if t.Type() == pcbnew.PCB_VIA_T]
            gone = set()
            for i, v1 in enumerate(vs):
                for v2 in vs[i + 1:]:
                    if id(v2) in gone or v1.GetNetCode() != v2.GetNetCode(): continue
                    if (v1.GetPosition() - v2.GetPosition()).EuclideanNorm() < FromMM(VIA_D + 0.25):
                        gone.add(id(v2)); b.Remove(v2)
            pcbnew.ZONE_FILLER(b).Fill(b.Zones())
            # drop GND vias that don't land in poured copper on both layers (their island was removed)
            gnd = b.FindNet("GND").GetNetCode(); zs = [z for z in b.Zones() if z.GetNetCode() == gnd]
            drop = []
            for t in b.GetTracks():
                if t.Type() == pcbnew.PCB_VIA_T and t.GetNetCode() == gnd:
                    p = t.GetPosition()
                    if b.GetCopperLayerCount() < 4 and not all(any(z.GetLayer() == L and z.GetFilledPolysList(L).Contains(pcbnew.VECTOR2I(p.x, p.y)) for z in zs) for L in (pcbnew.F_Cu, pcbnew.B_Cu)):
                        drop.append(t)
            for t in drop: b.Remove(t)
            if drop: pcbnew.ZONE_FILLER(b).Fill(b.Zones())
            rpt = os.path.join(here, f"{name}_drc.txt")
            pcbnew.WriteDRCReport(b, rpt, pcbnew.EDA_UNITS_MILLIMETRES, True)
            kinds = collections.Counter(re.findall(r"^\[(\w+)\]", open(rpt).read(), re.M))
            print(f"{name} attempt {attempt + 1}: {nseg} segments, {nvia} vias, failed {sorted(set(failed))}; DRC {dict(kinds)}")
            if not kinds.get("unconnected_items") and not kinds.get("clearance") and not kinds.get("hole_clearance"):
                break
            unc = set(re.findall(r"\[([^\]]+)\] of", open(rpt).read()))
            priority = list(dict.fromkeys(list(priority) + [f for f in failed] + [u for u in unc]))
        out = os.path.join(here, f"{name}_routed.kicad_pcb"); pcbnew.SaveBoard(out, b)
