"""Juris A-6 'The Brief': generate the two KiCad 7 boards (placement, nets, outline, silkscreen).

  control.kicad_pcb  70 x 64 mm  input stage, Baxandall, mixer, soft clip, pots, voice switch
  main.kicad_pcb    110 x 64 mm  48 V input, fuse, bulk cap, 12 V buck, 9 V and 30 V regulators,
                                 reverb module header + trimmers, connectors to the bought TPA3255 board

Signal parts are SMD on the bottom side of the control board (the pots occupy the top);
power parts are through-hole on the main board. Routing is done by route_pcbs.py (Freerouting).
Reference designators follow the schematic sheets A-E where the part exists there.
"""
import os, math
import pcbnew
from pcbnew import VECTOR2I, FromMM

LIB = "/usr/share/kicad/footprints"
OUT = os.path.dirname(os.path.abspath(__file__))
REV = "REV C  2026-11-24"

def mm(x, y): return VECTOR2I(FromMM(x), FromMM(y))

# ---------------- custom footprints ----------------
def fpshape(fp, kind, layer, a, b, w=0.12):
    c = pcbnew.FP_SHAPE(fp); c.SetShape(kind); c.SetLayer(layer)
    c.SetStart0(mm(*a)); c.SetEnd0(mm(*b)); c.SetWidth(FromMM(w)); c.SetDrawCoord()
    return c
def fp_alpha16(board):
    """Alpha 16 mm PCB-mount pot (RV16 family, PC pins). Pins 5.0 mm pitch, 7.5 mm behind the shaft.
    VERIFY against the chosen pot's drawing before ordering."""
    fp = pcbnew.FOOTPRINT(board); fp.SetFPID(pcbnew.LIB_ID("JPI", "POT_ALPHA16_V"))
    for i, x in enumerate((-5.0, 0.0, 5.0)):
        p = pcbnew.PAD(fp); p.SetNumber(str(i + 1)); p.SetShape(pcbnew.PAD_SHAPE_CIRCLE)
        p.SetAttribute(pcbnew.PAD_ATTRIB_PTH); p.SetLayerSet(pcbnew.PAD.PTHMask())
        p.SetSize(mm(2.2, 2.2)); p.SetDrillSize(mm(1.3, 1.3)); p.SetPos0(mm(x, 7.5)); p.SetPosition(mm(x, 7.5)); fp.Add(p)
    for layer, r in ((pcbnew.F_CrtYd, 8.6), (pcbnew.F_SilkS, 8.0), (pcbnew.F_SilkS, 3.5)):
        fp.Add(fpshape(fp, pcbnew.SHAPE_T_CIRCLE, layer, (0, 0), (r, 0)))
    return fp

def fp_toggle(board):
    """Sub-mini SPDT toggle, on-off-on, PC pins 4.7 mm pitch (bushing through the plate). VERIFY pitch."""
    fp = pcbnew.FOOTPRINT(board); fp.SetFPID(pcbnew.LIB_ID("JPI", "TOGGLE_SPDT_4.7"))
    for i, x in enumerate((-4.7, 0.0, 4.7)):
        p = pcbnew.PAD(fp); p.SetNumber(str(i + 1)); p.SetShape(pcbnew.PAD_SHAPE_OVAL)
        p.SetAttribute(pcbnew.PAD_ATTRIB_PTH); p.SetLayerSet(pcbnew.PAD.PTHMask())
        p.SetSize(mm(2.0, 3.2)); p.SetDrillSize(mm(1.4, 1.4)); p.SetPos0(mm(x, 0)); p.SetPosition(mm(x, 0)); fp.Add(p)
    fp.Add(fpshape(fp, pcbnew.SHAPE_T_RECT, pcbnew.F_SilkS, (-6.6, -4.0), (6.6, 4.0)))
    fp.Add(fpshape(fp, pcbnew.SHAPE_T_RECT, pcbnew.F_CrtYd, (-7.0, -4.4), (7.0, 4.4), 0.05))
    return fp

FP = {
    "R": ("Resistor_SMD", "R_0805_2012Metric"),
    "C": ("Capacitor_SMD", "C_0805_2012Metric"),
    "C1206": ("Capacitor_SMD", "C_1206_3216Metric"),
    "D": ("Diode_SMD", "D_SOD-123"),
    "TP": ("TestPoint", "TestPoint_Pad_D1.5mm"),
    "SOT23": ("Package_TO_SOT_SMD", "SOT-23"),
    "SOIC8": ("Package_SO", "SOIC-8_3.9x4.9mm_P1.27mm"),
    "TO92": ("Package_TO_SOT_THT", "TO-92_Inline_Wide"),
    "TO220": ("Package_TO_SOT_THT", "TO-220-3_Vertical"),
    "CP18": ("Capacitor_THT", "CP_Radial_D18.0mm_P7.50mm"),
    "CP8": ("Capacitor_THT", "CP_Radial_D8.0mm_P3.50mm"),
    "XH2": ("Connector_JST", "JST_XH_B2B-XH-A_1x02_P2.50mm_Vertical"),
    "XH3": ("Connector_JST", "JST_XH_B3B-XH-A_1x03_P2.50mm_Vertical"),
    "XH4": ("Connector_JST", "JST_XH_B4B-XH-A_1x04_P2.50mm_Vertical"),
    "XH6": ("Connector_JST", "JST_XH_B6B-XH-A_1x06_P2.50mm_Vertical"),
    "TB2": ("TerminalBlock_Phoenix", "TerminalBlock_Phoenix_MKDS-1,5-2-5.08_1x02_P5.08mm_Horizontal"),
    "FUSE": ("Fuse", "Fuseholder_Cylinder-5x20mm_Schurter_0031_8201_Horizontal_Open"),
    "HDR4": ("Connector_PinHeader_2.54mm", "PinHeader_1x04_P2.54mm_Vertical"),
    "HDR9": ("Connector_PinHeader_2.54mm", "PinHeader_1x09_P2.54mm_Vertical"),
    "TRIM": ("Potentiometer_THT", "Potentiometer_Bourns_3296W_Vertical"),
    "MH": ("MountingHole", "MountingHole_3.2mm_M3_Pad_Via"),
    "POT9": ("Potentiometer_THT", "Potentiometer_Alpha_RD901F-40-00D_Single_Vertical"),   # Alpha 9 mm vertical, per Alpha drawing
    "SOCK13": ("Connector_PinSocket_2.54mm", "PinSocket_1x13_P2.54mm_Vertical"),           # ABE module (13-pin SIP, 0.1 in)
    "HDR3": ("Connector_PinHeader_2.54mm", "PinHeader_1x03_P2.54mm_Vertical"),
}

def place_pot(B, ref, val, u, v, nets, P):
    """Alpha RD901F-40 9 mm vertical pot with its shaft at plate position (u, v); pins behind the shaft.
    Pin 1 = CCW end, 3 = CW end (viewed from the shaft). The two bracket tabs are tied to GND."""
    tx, ty = P(u, v)
    for rot in (0, 90, 180, 270):
        fp = B.add(ref, "POT9", 0, 0, nets, val, rot=rot)
        tabs = [pd for pd in fp.Pads() if pd.GetNumber() == ""]
        mx = sum(pd.GetPosition().x for pd in tabs) / 2; my = sum(pd.GetPosition().y for pd in tabs) / 2
        pins = [pd for pd in fp.Pads() if pd.GetNumber() in ("1", "2", "3")]
        if all(pd.GetPosition().y > my + FromMM(5) for pd in pins):
            tgt = B.xy(tx, ty); fp.Move(pcbnew.VECTOR2I(int(tgt.x - mx), int(tgt.y - my)))
            for pd in tabs: pd.SetNet(B.net("GND"))
            B.parts[-1] = (ref, val, "POT9", tx, ty, rot, "F")
            return fp
        B.b.Remove(fp); B.parts.pop()
    raise RuntimeError("no orientation puts the pins behind the shaft")

class Board:
    def __init__(self, name, w, h, cx=100.0, cy=100.0, oy=0.0):
        self.b = pcbnew.BOARD(); self.name = name; self.w, self.h = w, h; self.cx, self.cy = cx, cy; self.oy = oy
        self.nets = {}; self.parts = []
        ds = self.b.GetDesignSettings()
        ds.SetCopperLayerCount(4); self.b.SetCopperLayerCount(4)   # Rev C: 4 layers, In1 and In2 solid ground
        self.outline()

    def net(self, n):
        if n not in self.nets:
            ni = pcbnew.NETINFO_ITEM(self.b, n); self.b.Add(ni); self.nets[n] = ni
        return self.nets[n]

    def xy(self, x, y): return mm(self.cx + x, self.cy + y)

    def outline(self):
        x0, y0, x1, y1 = self.cx - self.w / 2, self.cy + self.oy - self.h / 2, self.cx + self.w / 2, self.cy + self.oy + self.h / 2
        r = 2.0
        segs = [((x0 + r, y0), (x1 - r, y0)), ((x1, y0 + r), (x1, y1 - r)), ((x1 - r, y1), (x0 + r, y1)), ((x0, y1 - r), (x0, y0 + r))]
        for a, bnd in segs:
            s = pcbnew.PCB_SHAPE(self.b); s.SetShape(pcbnew.SHAPE_T_SEGMENT); s.SetLayer(pcbnew.Edge_Cuts)
            s.SetStart(mm(*a)); s.SetEnd(mm(*bnd)); s.SetWidth(FromMM(0.1)); self.b.Add(s)
        for (cxx, cyy, a0) in ((x0 + r, y0 + r, 180), (x1 - r, y0 + r, 270), (x1 - r, y1 - r, 0), (x0 + r, y1 - r, 90)):
            s = pcbnew.PCB_SHAPE(self.b); s.SetShape(pcbnew.SHAPE_T_ARC); s.SetLayer(pcbnew.Edge_Cuts)
            s.SetCenter(mm(cxx, cyy))
            s.SetStart(mm(cxx + r * math.cos(math.radians(a0)), cyy + r * math.sin(math.radians(a0))))
            s.SetArcAngleAndEnd(pcbnew.EDA_ANGLE(90, pcbnew.DEGREES_T), True)
            s.SetWidth(FromMM(0.1)); self.b.Add(s)

    def add(self, ref, kind, x, y, nets, value="", rot=0, side="F", custom=None):
        if custom: fp = custom(self.b)
        else:
            lib, name = FP[kind]; fp = pcbnew.FootprintLoad(f"{LIB}/{lib}.pretty", name)
        fp.SetReference(ref); fp.SetValue(value or kind)
        fp.SetPosition(self.xy(x, y)); fp.SetOrientationDegrees(rot)
        self.b.Add(fp)
        if side == "B": fp.Flip(fp.GetPosition(), False)
        for pad_no, n in nets.items():
            pads = [p for p in fp.Pads() if p.GetNumber() == str(pad_no)]
            for p in pads: p.SetNet(self.net(n))
        fp.Reference().SetTextSize(mm(0.8, 0.8)); fp.Reference().SetTextThickness(FromMM(0.12))
        fp.Value().SetVisible(False)
        self.parts.append((ref, value or kind, kind, x, y, rot, side))
        return fp

    def cutout(self, x, y, w, h):
        s = pcbnew.PCB_SHAPE(self.b); s.SetShape(pcbnew.SHAPE_T_RECT); s.SetLayer(pcbnew.Edge_Cuts)
        s.SetStart(self.xy(x - w / 2, y - h / 2)); s.SetEnd(self.xy(x + w / 2, y + h / 2)); s.SetWidth(FromMM(0.1)); self.b.Add(s)

    def text(self, s, x, y, size=1.0, layer=pcbnew.F_SilkS, bold=False, justify=None):
        t = pcbnew.PCB_TEXT(self.b); t.SetText(s); t.SetPosition(self.xy(x, y)); t.SetLayer(layer)
        t.SetTextSize(mm(size, size)); t.SetTextThickness(FromMM(size * (0.2 if bold else 0.13)))
        if justify == "left": t.SetHorizJustify(pcbnew.GR_TEXT_H_ALIGN_LEFT)
        if layer in (pcbnew.B_SilkS,): t.SetMirrored(True)
        self.b.Add(t)

    def poly(self, pts, layer=pcbnew.F_SilkS):
        s = pcbnew.PCB_SHAPE(self.b); s.SetShape(pcbnew.SHAPE_T_POLY); s.SetLayer(layer); s.SetFilled(True); s.SetWidth(0)
        sp = pcbnew.SHAPE_POLY_SET(); sp.NewOutline()
        for x, y in pts: sp.Append(FromMM(self.cx + x), FromMM(self.cy + y))
        s.SetPolyShape(sp); self.b.Add(s)

    def insignia(self, x, y, size=8.0, layer=pcbnew.F_SilkS):
        """Juris mark: octagon on the 0.3125 / 0.375 / 0.3125 grid, four corners cut at 45 deg, gutters open."""
        a = size * 0.3125; bb = size * 0.375; g = size * 0.035; h = size / 2
        xs = [-h, -h + a, h - a, h]
        cells = []
        for i in range(3):
            for j in range(3):
                x0, x1 = xs[i] + g, xs[i + 1] - g; y0, y1 = xs[j] + g, xs[j + 1] - g
                if i != 1 and j != 1:                                   # corner patch -> triangle (corner removed)
                    cx_, cy_ = (xs[0] if i == 0 else xs[3]), (xs[0] if j == 0 else xs[3])
                    pts = [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]
                    far = max(pts, key=lambda p: -abs(p[0] - cx_) - abs(p[1] - cy_))
                    pts = [p for p in pts if p != min(pts, key=lambda p: abs(p[0] - cx_) + abs(p[1] - cy_))]
                    cells.append(pts)
                else:
                    cells.append([(x0, y0), (x1, y0), (x1, y1), (x0, y1)])
        for c in cells: self.poly([(x + px, y + py) for px, py in c], layer)

    def zone(self, netname, layer):
        z = pcbnew.ZONE(self.b); z.SetLayer(layer); z.SetNet(self.net(netname))
        x0, y0, x1, y1 = self.cx - self.w / 2 + 0.5, self.cy + self.oy - self.h / 2 + 0.5, self.cx + self.w / 2 - 0.5, self.cy + self.oy + self.h / 2 - 0.5
        ol = z.Outline(); ol.NewOutline()
        for px, py in ((x0, y0), (x1, y0), (x1, y1), (x0, y1)): ol.Append(FromMM(px), FromMM(py))
        z.SetMinThickness(FromMM(0.25)); z.SetLocalClearance(FromMM(0.4))
        z.SetPadConnection(pcbnew.ZONE_CONNECTION_THERMAL); z.SetThermalReliefGap(FromMM(0.4)); z.SetThermalReliefSpokeWidth(FromMM(0.5))
        z.SetIslandRemovalMode(pcbnew.ISLAND_REMOVAL_MODE_ALWAYS)
        self.b.Add(z)

    def legalise(self, refs, margin=0.35, step=0.5, max_r=30.0):
        """Move the listed (SMD) footprints to the nearest free spot: no overlap with any other
        footprint's courtyard/pads on the same side, no overlap with through-hole pads, inside the board."""
        fps = {f.GetReference(): f for f in self.b.GetFootprints()}
        bx0, by0 = FromMM(self.cx - self.w / 2 + 1.0), FromMM(self.cy + self.oy - self.h / 2 + 1.0)
        bx1, by1 = FromMM(self.cx + self.w / 2 - 1.0), FromMM(self.cy + self.oy + self.h / 2 - 1.0)
        def box(f):
            bb = f.GetBoundingBox(False, False)
            m = FromMM(margin)
            return (bb.GetLeft() - m, bb.GetTop() - m, bb.GetRight() + m, bb.GetBottom() + m)
        def padboxes(f):
            out = []
            for p in f.Pads():
                if p.GetAttribute() == pcbnew.PAD_ATTRIB_PTH or p.GetAttribute() == pcbnew.PAD_ATTRIB_NPTH:
                    bb = p.GetBoundingBox(); m = FromMM(margin + 0.2)
                    out.append((bb.GetLeft() - m, bb.GetTop() - m, bb.GetRight() + m, bb.GetBottom() + m))
            return out
        hit = lambda a, b: not (a[2] <= b[0] or b[2] <= a[0] or a[3] <= b[1] or b[3] <= a[1])
        placed = []                                  # boxes of already-legal bottom-side parts
        tht = []
        for r, f in fps.items():
            tht += padboxes(f)
            if r not in refs and f.IsFlipped(): placed.append(box(f))
        for d in self.b.GetDrawings():                  # internal cutouts
            if d.GetLayer() == pcbnew.Edge_Cuts and d.GetShape() == pcbnew.SHAPE_T_RECT:
                bb = d.GetBoundingBox(); m = FromMM(1.0)
                tht.append((bb.GetLeft() - m, bb.GetTop() - m, bb.GetRight() + m, bb.GetBottom() + m))
        texts = []
        for r in refs:
            f = fps[r]; start = f.GetPosition()
            best = None
            rr = 0.0
            while rr <= max_r and best is None:
                n = max(1, int(2 * math.pi * rr / step)) if rr > 0 else 1
                for k in range(n):
                    a = 2 * math.pi * k / n
                    f.SetPosition(VECTOR2I(start.x + FromMM(rr * math.cos(a)), start.y + FromMM(rr * math.sin(a))))
                    bb = box(f)
                    if bb[0] < bx0 or bb[1] < by0 or bb[2] > bx1 or bb[3] > by1: continue
                    if any(hit(bb, o) for o in placed) or any(hit(bb, t) for t in tht): continue
                    best = f.GetPosition(); break
                rr += step
            if best is None: raise RuntimeError(f"no room for {r}")
            f.SetPosition(best); placed.append(box(f))
        return True

    def save(self):
        path = os.path.join(OUT, f"{self.name}{os.environ.get('BOARDTAG', '')}.kicad_pcb")
        pcbnew.SaveBoard(path, self.b)
        return path

# ---------------- control board ----------------
def control_board():
    B = Board("control", 80.0, 74.0, oy=3.0)          # front edge cut back 6 mm to clear the window roof
    # pots and switch on top. Local coords: x = u, y = -(v - 15) (KiCad y grows toward the rear).
    P = lambda u, v: (u, -(v - 15.0))
    # (ref, value, u, v, (pin1 CCW, wiper, pin3 CW)): clockwise = louder / more bass / more treble
    pots = [("VR1", "VOLUME 50kA", -22, 30, ("VG", "VOL_W", "VOL_TOP")),
            ("VR2", "BASS 100kB", 0, 30, ("B2", "BW", "B1")),
            ("VR3", "TREBLE 100kB", 22, 30, ("T2", "TW", "T1")),
            ("VR4", "REVERB 50kA", -22, 0, ("VG", "REV_W", "RET")),
            ("VR5", "MASTER 50kA", 0, 0, ("VG", "MST_W", "MST_TOP"))]
    for ref, val, u, v, (n1, nw, n3) in pots:
        place_pot(B, ref, val, u, v, {1: n1, 2: nw, 3: n3}, P)
    # voice toggle (C&K 7103, solder lugs) mounts on the plate and wires to these pads
    tx_, ty_ = P(22, 0)
    B.cutout(tx_, ty_, 10.0, 16.0)                 # the toggle's body drops through this window
    B.add("S1", "HDR3", tx_ - 8.5, ty_ - 2.54, {1: "BRIGHT", 2: "NM", 3: "DARK"}, "TO VOICE TOGGLE", rot=0, side="B")
    B.add("U8", "SOIC8", 30, 24.0, {1: "VG", 2: "GND", 3: "+30V", 8: "NR"}, "TLE2426ID", side="B")
    B.add("C19", "C1206", 34, 28.0, {1: "NR", 2: "GND"}, "1u", rot=0, side="B")
    # connectors on the bottom, rear edge
    B.add("J1", "XH2", -12, 36.0, {1: "IN", 2: "GND"}, "INPUT (to jack)", side="B")
    B.add("J2", "XH6", 14, 36.0, {1: "+30V", 2: "GND", 3: "SEND", 4: "RETURN", 5: "DRIVE", 6: "GND"}, "TO MAIN", side="B")
    for i, (mx, my) in enumerate(((-31.5, -28.5), (31.5, -28.5), (-31.5, 28.5), (31.5, 28.5))):
        pass  # the control board hangs on the pot bushings; no mounting holes
    # op-amps (bottom)
    B.add("U1", "SOIC8", -13, 0.0, {1: "TONE_OUT", 2: "SUM1", 3: "VG", 4: "GND", 5: "NA", 6: "NM", 7: "U1B_OUT", 8: "+30V"}, "NJM4558", side="B", rot=0)
    u2x, u2y, u2r = [float(v) for v in os.environ.get("U2POS", "12,0,0").split(",")]
    B.add("U2", "SOIC8", u2x, u2y, {1: "MIX", 2: "SUM2", 3: "VG", 4: "GND", 5: "VG", 6: "SUM3", 7: "CLIP", 8: "+30V"}, "NJM4558", side="B", rot=u2r)
    # passives (bottom). (ref, kind, value, x, y, rot, pad1, pad2)
    S = [
        # sheet A: input stage
        ("C1", "C", "4.7n C0G", -18, 30, 90, "IN", "NA"), ("R1", "R", "680k", -21, 30, 90, "NA", "VG"),
        ("R2", "R", "100k", -16, 4.5, 0, "U1B_OUT", "NM"), ("C2", "C", "1.5n C0G", -16, 7.0, 0, "DARK", "U1B_OUT"),
        ("R3", "R", "12k", -20, -4.0, 90, "NM", "N_R3"), ("C3", "C1206", "39n film/C0G", -24, -4.0, 90, "N_R3", "VG"),
        ("R4", "R", "4.7k", -28, -4.0, 90, "BRIGHT", "N_R4"), ("C4", "C1206", "22n", -31.5, -4.0, 90, "N_R4", "VG"),
        ("C5", "C1206", "1u", -24, 8.0, 0, "U1B_OUT", "VOL_TOP"),
        # sheet B: Baxandall
        ("R5", "R", "10k", -6, -8.0, 0, "VOL_W", "B1"), ("R6", "R", "10k", 6, -8.0, 0, "B2", "TONE_OUT"),
        ("C6", "C1206", "39n film", -6, -11.5, 0, "B1", "BW"), ("C7", "C1206", "39n film", 6, -11.5, 0, "BW", "B2"),
        ("R7", "R", "3.3k", -2, -4.0, 90, "BW", "SUM1"), ("R8", "R", "1.5k", 2, -4.0, 90, "TW", "SUM1"),
        ("C8", "C", "4.7n C0G", 12, -12.0, 0, "VOL_W", "T1"), ("C9", "C", "4.7n C0G", 18, -12.0, 0, "T2", "TONE_OUT"),
        # sheet C: send, mixer, master
        ("R10", "R", "22k", 4, 7.0, 0, "TONE_OUT", "SEND_D"), ("R11", "R", "10k", 4, 9.5, 0, "SEND_D", "VG"),
        ("C14", "C1206", "1u", 4, 12.5, 0, "SEND_D", "SEND"),
        ("R9", "R", "10k", 18, 4.5, 0, "TONE_OUT", "SUM2"), ("R12", "R", "10k", 18, 7.0, 0, "REV_W", "SUM2"),
        ("R13", "R", "10k", 18, 9.5, 0, "MIX", "SUM2"), ("C11", "C1206", "1u", 26, 6.0, 90, "MIX", "MST_TOP"),
        # sheet D: soft clip + drive
        ("R14", "R", "10k", 18, -4.5, 0, "MST_W", "SUM3"), ("R15", "R", "33k", 18, -7.0, 0, "SUM3", "CLIP"),
        ("R16", "R", "330", 28, -6.0, 90, "SUM3", "DM"),
        ("R17", "R", "10k*", 4, 15.0, 0, "CLIP", "DRV"), ("R18", "R", "10k*", 4, 17.5, 0, "DRV", "VG"),
        ("C13", "C1206", "10u 50V", 4, 20.5, 0, "DRV", "DRIVE"),
        # supply decoupling
        ("C15", "C1206", "10u 50V", 28, 4.0, 90, "+30V", "GND"), ("C16", "C1206", "10u 50V", 30.5, 4.0, 90, "VG", "GND"),
        ("C17", "C", "100n", -11, 4.0, 0, "+30V", "GND"), ("C18", "C", "100n", 11, 4.0, 0, "+30V", "GND"),
    ]
    for ref, kind, val, x, y, rot, a, b2 in S:
        SX, SY = [float(v) for v in os.environ.get("SCALE", "1.0,1.0").split(",")]
        B.add(ref, kind, x * SX, y * SY, {1: a, 2: b2}, val, rot=rot, side="B")
    # soft-clip diode strings (D1-D5 forward DM -> CLIP, D6-D10 reverse), SOD-123, bottom
    ND = 7                                            # diodes per string: plateau ~3.8 V peak at the clip stage
    chainA = ["DM"] + [f"DA{k}" for k in range(1, ND)] + ["CLIP"]
    chainB = ["CLIP"] + [f"DB{k}" for k in range(1, ND)] + ["DM"]
    DX, DY1, DY2, DP = [float(v) for v in os.environ.get("DPOS", "22,-30,-25.5,2.6").split(",")]
    for i in range(ND):
        B.add(f"D{i+1}", "D", DX + i * DP, DY1, {2: chainA[i], 1: chainA[i + 1]}, "1N4148W", rot=90, side="B")
        B.add(f"D{i+1+ND}", "D", DX + i * DP, DY2, {2: chainB[i], 1: chainB[i + 1]}, "1N4148W", rot=90, side="B")
    # silkscreen: control legends (top, readable from the plate side during assembly) and the Juris block (bottom)
    for ref, val, u, v, _ in pots:
        x, y = P(u, v); B.text(val.split()[0], x, y - 9.6, 1.0, bold=True)
    x, y = P(22, 0); B.text("BRIGHT · NORMAL · DARK", x, y - 10.5, 0.8)
    B.insignia(-31, -28.0, 5.5, pcbnew.B_SilkS)
    B.text("JURIS PROFESSIONAL INSTRUMENTS", 3, -30.6, 1.0, pcbnew.B_SilkS, bold=True)
    B.text("JURIS A-6  CONTROL ASSEMBLY  JPI-A6-C", 3, -28.7, 0.8, pcbnew.B_SilkS)
    B.text(REV + "  OPERATOR SERVICEABLE. SEE NOTICE.", 3, -26.9, 0.8, pcbnew.B_SilkS)
    B.text("J1 INPUT: TIP / SLEEVE", -12, 32.0, 0.8, pcbnew.B_SilkS)
    B.text("J2  +30 GND SEND RET DRV GND", 14, 32.0, 0.8, pcbnew.B_SilkS)
    # test points (bottom pads, probe from the back with the board out): rails, virtual ground, drive
    for i, (n, x, y) in enumerate((("+30V", 26, 32), ("VG", 30, 32), ("GND", 34, 32), ("CLIP", 32, -16), ("DRV", 8, 22), ("SEND", 2, 22))):
        B.add(f"TP{i+1}", "TP", x, y, {1: n}, n, side="B")
        B.text(n.replace("+", ""), x, y + 2.0, 0.8, pcbnew.B_SilkS)
    smd = [p[0] for p in B.parts if p[2] in ("R", "C", "C1206", "D", "SOIC8", "TP")]
    order = ["U1", "U2"] + [r for r in smd if r not in ("U1", "U2")]
    B.legalise(order, margin=0.75)
    B.zone("GND", pcbnew.B_Cu); B.zone("GND", pcbnew.F_Cu); B.zone("GND", pcbnew.In1_Cu); B.zone("GND", pcbnew.In2_Cu)
    return B

# ---------------- main board ----------------
def main_board():
    B = Board("main", 110.0, 64.0, cx=300.0, cy=100.0)
    for i, (mx, my) in enumerate(((-49, -26), (49, -26), (-49, 26), (49, 26))):
        B.add(f"H{i+1}", "MH", mx, my, {1: "GND"}, "M3 standoff")
    # left third: 48 V in, fuse, bulk cap, buck and the amp feed (the noisy currents); right: regulators and reverb
    B.add("J10", "TB2", -46, -12, {1: "+48_IN", 2: "GND"}, "48V IN (from DIN + switch)", rot=90)
    B.add("F1", "FUSE", -28, -25, {1: "+48_IN", 2: "+48"}, "5A T 5x20").Reference().SetVisible(False)
    B.add("C20", "CP18", -27, -8, {1: "+48", 2: "GND"}, "2200u 63V").Reference().SetVisible(False)
    B.add("J11", "TB2", -46, 12, {1: "+48", 2: "GND"}, "48V TO AMP BOARD", rot=90)
    # 3e Audio 480-1-29A input (JST 2.5 mm, 3-pin): 1 IN+, 2 IN-, 3 AGND. Its input is balanced by default, so U9
    # makes a balanced pair: U9A buffers DRIVE (biased to VB = 15 V), U9B inverts it; both AC-coupled to the board.
    B.add("J12", "XH3", -30, 24, {1: "AMP_P", 2: "AMP_N", 3: "GND"}, "TO AMP IN+ IN- AGND")
    B.add("U9", "SOIC8", -18, 22, {1: "OUTP_DC", 2: "OUTP_DC", 3: "DRIVE", 4: "GND", 5: "VB", 6: "INV_N", 7: "OUTN_DC", 8: "+30V"}, "NJM4558", side="B")
    B.add("U4", "HDR4", -10, -8, {1: "+48", 2: "GND", 3: "GND", 4: "+12V"}, "12V BUCK MODULE (60V in)", rot=90)
    # power-on mute: holds the 3e board's RESET (J5 pin 4) low for about a second after the 12 V rail comes up
    B.add("J16", "XH2", -41, 28, {1: "RESET_N", 2: "GND"}, "TO AMP J5: 4 RESET, 5 GND")
    B.add("Q1", "SOT23", -24, 28, {1: "MUTE_G", 2: "GND", 3: "RESET_N"}, "2N7002", side="B")
    B.add("U5", "TO220", -6, 12, {1: "+12V", 2: "GND", 3: "+9V"}, "7809")
    B.add("U6", "TO220", 10, 12, {1: "ADJ", 2: "+30V", 3: "+48"}, "LM317HVT")   # 60 V in-out rating: 48 V in, 0 V out at switch-on
    B.add("J13", "XH6", 14, 25, {1: "+30V", 2: "GND", 3: "SEND", 4: "RETURN", 5: "DRIVE", 6: "GND"}, "TO CONTROL")
    # Accu-Bell Effector (ABE) in a 13-way 0.1 in socket. Pin order per the Accu-Bell datasheet:
    # VDD GND IN OUT1- OUT1+ OUT2+ OUT2- GPIO1 GPIO2 GPIO3 GPIO4 GPIO5 VPOT (some copies number it from the VPOT end;
    # the order is the same, so line the module's printed VDD / VPOT labels up with the legend).
    ABE = ["+9V", "GND", "REV_IN", None, "R_O1", "R_O2", None, "SEL", "TONE_V", "DECAY_V", "PRE_V", None, "VPOT"]
    ABE_N = ["VDD", "GND", "IN", "O1-", "O1+", "O2+", "O2-", "G1", "G2", "G3", "G4", "G5", "VPOT"]
    B.add("U7", "SOCK13", 48, -15.24, {i + 1: n for i, n in enumerate(ABE) if n}, "ACCU-BELL EFFECTOR", rot=0)
    for i, nm in enumerate(ABE_N):
        B.text(nm, 51.6, -15.24 + i * 2.54, 0.8)
    for i, (nm, n) in enumerate((("TONE", "TONE_V"), ("DECAY", "DECAY_V"), ("PRE", "PRE_V"))):
        B.add(f"RV{i+1}", "TRIM", 30, 2 + i * 7.5, {1: "GND", 2: n, 3: "VPOT"}, f"{nm} 50k")
    S = [
        ("C21", "C1206", "1u 100V", -10, -22, 0, "+48", "GND"),
        ("C22", "C1206", "10u 25V", -20, 14, 90, "+12V", "GND"),
        ("C23", "C1206", "1u 25V", -9, 22, 0, "+12V", "GND"),
        ("C24", "C1206", "10u 25V", -3, 22, 0, "+9V", "GND"),
        ("C25", "C1206", "1u 100V", 13, 3, 0, "+48", "GND"),
        ("C26", "C1206", "10u 50V", 20, 18, 90, "+30V", "GND"),
        ("R20", "R", "240", 4, 3, 0, "+30V", "ADJ"),
        ("R21", "R", "5.6k", 4, 6, 0, "ADJ", "GND"),
        ("C30", "C1206", "1u", 40, -12, 90, "SEND", "REV_IN"),
        ("C31", "C1206", "1u", 40, -4, 90, "R_O1", "R_O1C"), ("R30", "R", "1k", 40, 2, 90, "R_O1C", "RETURN"),
        ("C32", "C1206", "1u", 44, -4, 90, "R_O2", "R_O2C"), ("R31", "R", "1k", 44, 2, 90, "R_O2C", "RETURN"),
        ("R32", "R", "18k", 40, 8, 90, "VPOT", "SEL"), ("R33", "R", "33k", 44, 8, 90, "SEL", "GND"),
        ("C27", "C", "100n", 44, -12, 90, "+9V", "GND"),
        ("R19", "R", "100k", -24, 20, 0, "DRIVE", "VB"),
        ("R40", "R", "10k", -12, 26, 0, "+30V", "VB"), ("R41", "R", "10k", -12, 28.5, 0, "VB", "GND"),
        ("C40", "C1206", "10u 25V", -6, 27, 0, "VB", "GND"),
        ("R43", "R", "10k", -14, 17, 0, "OUTP_DC", "INV_N"), ("R44", "R", "10k", -18, 17, 0, "INV_N", "OUTN_DC"),
        ("C41", "C1206", "10u 25V", -26, 15, 0, "OUTP_DC", "AMP_P"), ("C42", "C1206", "10u 25V", -32, 15, 0, "OUTN_DC", "AMP_N"),
        ("R45", "R", "100k", -36, 20, 90, "AMP_P", "GND"), ("R46", "R", "100k", -39, 20, 90, "AMP_N", "GND"),
        ("C43", "C", "100n", -22, 26, 0, "+30V", "GND"),
        ("C50", "C1206", "1u 25V", -20, 24, 0, "+12V", "MUTE_G"), ("R50", "R", "1M", -24, 24, 0, "MUTE_G", "GND"),
    ]
    for ref, kind, val, x, y, rot, a, b2 in S:
        B.add(ref, kind, x, y, {1: a, 2: b2}, val, rot=rot, side="B")
    B.add("D16", "D", -28, 24, {1: "MUTE_G", 2: "GND"}, "1N4148W", rot=0, side="B")      # clamps the gate when 12 V falls
    for i, (n, x, y) in enumerate((("+48", -20, -18), ("+12V", -4, -16), ("+9V", -2, 26), ("+30V", 16, 18), ("GND", 22, 26), ("AMP_P", -34, 18), ("AMP_N", -38, 18))):
        B.add(f"TP{i+1}", "TP", x, y, {1: n}, n, side="B")
    # silkscreen (top faces the speaker; bottom faces the back plate and is what you see when the module is out)
    B.text("48V IN", -46, -19, 1.0, bold=True); B.text("TO AMP", -46, 3.5, 1.0, bold=True)
    B.text("DRIVE", -30, 20, 0.8); B.text("12V BUCK", -10, -16.5, 0.8); B.text("MUTE", -41, 24, 0.8); B.text("9V", -6, 5, 0.9); B.text("30V", 10, 5, 0.9)
    B.text("REVERB", 48, -19.5, 0.9, bold=True)
    for i, nm in enumerate(("TONE", "DECAY", "PRE")): B.text(nm, 20.5, 2 + i * 7.5, 0.8)
    B.text("F1 5A T", -28, -21, 0.9, bold=True); B.text("TO CONTROL", 14, 29.5, 0.8)
    B.legalise(["U9", "Q1"] + [p[0] for p in B.parts if p[2] in ("R", "C", "C1206", "D", "TP")])
    B.insignia(-32, 9, 7.0, pcbnew.F_SilkS)
    B.text("JURIS PROFESSIONAL INSTRUMENTS", 30, -28.5, 1.0, bold=True)
    B.text("JURIS A-6  MAIN ASSEMBLY  JPI-A6-M", 30, -26.6, 0.8)
    B.text(REV + "  48 V DC ONLY", 30, -24.9, 0.8)
    B.zone("GND", pcbnew.B_Cu); B.zone("GND", pcbnew.F_Cu); B.zone("GND", pcbnew.In1_Cu); B.zone("GND", pcbnew.In2_Cu)
    return B

if __name__ == "__main__":
    for f in (control_board, main_board):
        bd = f(); p = bd.save()
        print("saved", p, len(bd.parts), "parts,", len(bd.nets), "nets")
