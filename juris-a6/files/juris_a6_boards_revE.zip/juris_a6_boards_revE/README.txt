Juris A-6 boards, 2026-11-25
Main board JPI-A6-M: Rev D, 100 x 64 mm, 4-layer. U4 = RECOM R-78HB12-0.5 with C21 3.3 uF 100 V at its input.
Control board JPI-A6-C: Rev E, 80 x 74 mm, 4-layer. Adds R60 (12k) and J3 (2-pin) for the A-6 Head 8/4 ohm LOAD switch: closing J3 puts R60 across R18. Combo and cab: leave J3 unconnected (8 ohm).
R17 = 18k: amp averages <= ~120 W with every knob maxed (8 ohm), ~100 W at 4 ohm with J3 closed.
Both: DRC clean (lib_footprint_issues are local library-path notices only).
The combo back plate DXF is included for the amp-board hole pattern; the head has its own back plate (juris_a6_head_back_plate.dxf).
